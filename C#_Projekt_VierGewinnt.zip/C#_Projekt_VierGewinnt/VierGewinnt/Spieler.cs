﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VierGewinnt
{
    public class Spieler
    {
        public char spielfigur;
        public string name = String.Empty;
    }
}
