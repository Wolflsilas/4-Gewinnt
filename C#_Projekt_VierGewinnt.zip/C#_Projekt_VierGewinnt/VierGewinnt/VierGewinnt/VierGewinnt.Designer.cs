﻿namespace VierGewinnt
{
    partial class VierGewinnt
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.p_VierGewinnt = new System.Windows.Forms.Panel();
            this.row7_line6 = new System.Windows.Forms.Label();
            this.row7_line5 = new System.Windows.Forms.Label();
            this.row7_line4 = new System.Windows.Forms.Label();
            this.row7_line3 = new System.Windows.Forms.Label();
            this.row7_line2 = new System.Windows.Forms.Label();
            this.row7_line1 = new System.Windows.Forms.Label();
            this.row6_line6 = new System.Windows.Forms.Label();
            this.row6_line5 = new System.Windows.Forms.Label();
            this.row6_line4 = new System.Windows.Forms.Label();
            this.row6_line3 = new System.Windows.Forms.Label();
            this.row6_line2 = new System.Windows.Forms.Label();
            this.row6_line1 = new System.Windows.Forms.Label();
            this.row5_line6 = new System.Windows.Forms.Label();
            this.row5_line5 = new System.Windows.Forms.Label();
            this.row5_line4 = new System.Windows.Forms.Label();
            this.row5_line3 = new System.Windows.Forms.Label();
            this.row5_line2 = new System.Windows.Forms.Label();
            this.row5_line1 = new System.Windows.Forms.Label();
            this.row4_line6 = new System.Windows.Forms.Label();
            this.row4_line5 = new System.Windows.Forms.Label();
            this.row4_line4 = new System.Windows.Forms.Label();
            this.row4_line3 = new System.Windows.Forms.Label();
            this.row4_line2 = new System.Windows.Forms.Label();
            this.row4_line1 = new System.Windows.Forms.Label();
            this.row3_line6 = new System.Windows.Forms.Label();
            this.row3_line5 = new System.Windows.Forms.Label();
            this.row3_line4 = new System.Windows.Forms.Label();
            this.row3_line3 = new System.Windows.Forms.Label();
            this.row3_line2 = new System.Windows.Forms.Label();
            this.row3_line1 = new System.Windows.Forms.Label();
            this.row2_line6 = new System.Windows.Forms.Label();
            this.row2_line5 = new System.Windows.Forms.Label();
            this.row2_line4 = new System.Windows.Forms.Label();
            this.row2_line3 = new System.Windows.Forms.Label();
            this.row2_line2 = new System.Windows.Forms.Label();
            this.row2_line1 = new System.Windows.Forms.Label();
            this.row1_line6 = new System.Windows.Forms.Label();
            this.row1_line5 = new System.Windows.Forms.Label();
            this.row1_line4 = new System.Windows.Forms.Label();
            this.row1_line3 = new System.Windows.Forms.Label();
            this.row1_line2 = new System.Windows.Forms.Label();
            this.row1_line1 = new System.Windows.Forms.Label();
            this.gB_VierGewinnt = new System.Windows.Forms.GroupBox();
            this.row7 = new System.Windows.Forms.Button();
            this.row6 = new System.Windows.Forms.Button();
            this.row5 = new System.Windows.Forms.Button();
            this.row4 = new System.Windows.Forms.Button();
            this.row3 = new System.Windows.Forms.Button();
            this.row2 = new System.Windows.Forms.Button();
            this.row1 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.txt_info = new System.Windows.Forms.TextBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.p_VierGewinnt.SuspendLayout();
            this.gB_VierGewinnt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // p_VierGewinnt
            // 
            this.p_VierGewinnt.Controls.Add(this.row7_line6);
            this.p_VierGewinnt.Controls.Add(this.row7_line5);
            this.p_VierGewinnt.Controls.Add(this.row7_line4);
            this.p_VierGewinnt.Controls.Add(this.row7_line3);
            this.p_VierGewinnt.Controls.Add(this.row7_line2);
            this.p_VierGewinnt.Controls.Add(this.row7_line1);
            this.p_VierGewinnt.Controls.Add(this.row6_line6);
            this.p_VierGewinnt.Controls.Add(this.row6_line5);
            this.p_VierGewinnt.Controls.Add(this.row6_line4);
            this.p_VierGewinnt.Controls.Add(this.row6_line3);
            this.p_VierGewinnt.Controls.Add(this.row6_line2);
            this.p_VierGewinnt.Controls.Add(this.row6_line1);
            this.p_VierGewinnt.Controls.Add(this.row5_line6);
            this.p_VierGewinnt.Controls.Add(this.row5_line5);
            this.p_VierGewinnt.Controls.Add(this.row5_line4);
            this.p_VierGewinnt.Controls.Add(this.row5_line3);
            this.p_VierGewinnt.Controls.Add(this.row5_line2);
            this.p_VierGewinnt.Controls.Add(this.row5_line1);
            this.p_VierGewinnt.Controls.Add(this.row4_line6);
            this.p_VierGewinnt.Controls.Add(this.row4_line5);
            this.p_VierGewinnt.Controls.Add(this.row4_line4);
            this.p_VierGewinnt.Controls.Add(this.row4_line3);
            this.p_VierGewinnt.Controls.Add(this.row4_line2);
            this.p_VierGewinnt.Controls.Add(this.row4_line1);
            this.p_VierGewinnt.Controls.Add(this.row3_line6);
            this.p_VierGewinnt.Controls.Add(this.row3_line5);
            this.p_VierGewinnt.Controls.Add(this.row3_line4);
            this.p_VierGewinnt.Controls.Add(this.row3_line3);
            this.p_VierGewinnt.Controls.Add(this.row3_line2);
            this.p_VierGewinnt.Controls.Add(this.row3_line1);
            this.p_VierGewinnt.Controls.Add(this.row2_line6);
            this.p_VierGewinnt.Controls.Add(this.row2_line5);
            this.p_VierGewinnt.Controls.Add(this.row2_line4);
            this.p_VierGewinnt.Controls.Add(this.row2_line3);
            this.p_VierGewinnt.Controls.Add(this.row2_line2);
            this.p_VierGewinnt.Controls.Add(this.row2_line1);
            this.p_VierGewinnt.Controls.Add(this.row1_line6);
            this.p_VierGewinnt.Controls.Add(this.row1_line5);
            this.p_VierGewinnt.Controls.Add(this.row1_line4);
            this.p_VierGewinnt.Controls.Add(this.row1_line3);
            this.p_VierGewinnt.Controls.Add(this.row1_line2);
            this.p_VierGewinnt.Controls.Add(this.row1_line1);
            this.p_VierGewinnt.Location = new System.Drawing.Point(39, 132);
            this.p_VierGewinnt.Name = "p_VierGewinnt";
            this.p_VierGewinnt.Size = new System.Drawing.Size(504, 390);
            this.p_VierGewinnt.TabIndex = 0;
            // 
            // row7_line6
            // 
            this.row7_line6.BackColor = System.Drawing.Color.Silver;
            this.row7_line6.Location = new System.Drawing.Point(435, 327);
            this.row7_line6.Name = "row7_line6";
            this.row7_line6.Size = new System.Drawing.Size(50, 50);
            this.row7_line6.TabIndex = 47;
            // 
            // row7_line5
            // 
            this.row7_line5.BackColor = System.Drawing.Color.Silver;
            this.row7_line5.Location = new System.Drawing.Point(435, 266);
            this.row7_line5.Name = "row7_line5";
            this.row7_line5.Size = new System.Drawing.Size(50, 50);
            this.row7_line5.TabIndex = 46;
            // 
            // row7_line4
            // 
            this.row7_line4.BackColor = System.Drawing.Color.Silver;
            this.row7_line4.Location = new System.Drawing.Point(435, 203);
            this.row7_line4.Name = "row7_line4";
            this.row7_line4.Size = new System.Drawing.Size(50, 50);
            this.row7_line4.TabIndex = 45;
            // 
            // row7_line3
            // 
            this.row7_line3.BackColor = System.Drawing.Color.Silver;
            this.row7_line3.Location = new System.Drawing.Point(435, 142);
            this.row7_line3.Name = "row7_line3";
            this.row7_line3.Size = new System.Drawing.Size(50, 50);
            this.row7_line3.TabIndex = 44;
            // 
            // row7_line2
            // 
            this.row7_line2.BackColor = System.Drawing.Color.Silver;
            this.row7_line2.Location = new System.Drawing.Point(435, 78);
            this.row7_line2.Name = "row7_line2";
            this.row7_line2.Size = new System.Drawing.Size(50, 50);
            this.row7_line2.TabIndex = 43;
            // 
            // row7_line1
            // 
            this.row7_line1.BackColor = System.Drawing.Color.Silver;
            this.row7_line1.Location = new System.Drawing.Point(435, 15);
            this.row7_line1.Name = "row7_line1";
            this.row7_line1.Size = new System.Drawing.Size(50, 50);
            this.row7_line1.TabIndex = 42;
            // 
            // row6_line6
            // 
            this.row6_line6.BackColor = System.Drawing.Color.Silver;
            this.row6_line6.Location = new System.Drawing.Point(367, 327);
            this.row6_line6.Name = "row6_line6";
            this.row6_line6.Size = new System.Drawing.Size(50, 50);
            this.row6_line6.TabIndex = 41;
            // 
            // row6_line5
            // 
            this.row6_line5.BackColor = System.Drawing.Color.Silver;
            this.row6_line5.Location = new System.Drawing.Point(367, 266);
            this.row6_line5.Name = "row6_line5";
            this.row6_line5.Size = new System.Drawing.Size(50, 50);
            this.row6_line5.TabIndex = 40;
            // 
            // row6_line4
            // 
            this.row6_line4.BackColor = System.Drawing.Color.Silver;
            this.row6_line4.Location = new System.Drawing.Point(367, 203);
            this.row6_line4.Name = "row6_line4";
            this.row6_line4.Size = new System.Drawing.Size(50, 50);
            this.row6_line4.TabIndex = 39;
            // 
            // row6_line3
            // 
            this.row6_line3.BackColor = System.Drawing.Color.Silver;
            this.row6_line3.Location = new System.Drawing.Point(367, 142);
            this.row6_line3.Name = "row6_line3";
            this.row6_line3.Size = new System.Drawing.Size(50, 50);
            this.row6_line3.TabIndex = 38;
            // 
            // row6_line2
            // 
            this.row6_line2.BackColor = System.Drawing.Color.Silver;
            this.row6_line2.Location = new System.Drawing.Point(367, 78);
            this.row6_line2.Name = "row6_line2";
            this.row6_line2.Size = new System.Drawing.Size(50, 50);
            this.row6_line2.TabIndex = 37;
            // 
            // row6_line1
            // 
            this.row6_line1.BackColor = System.Drawing.Color.Silver;
            this.row6_line1.Location = new System.Drawing.Point(367, 15);
            this.row6_line1.Name = "row6_line1";
            this.row6_line1.Size = new System.Drawing.Size(50, 50);
            this.row6_line1.TabIndex = 36;
            // 
            // row5_line6
            // 
            this.row5_line6.BackColor = System.Drawing.Color.Silver;
            this.row5_line6.Location = new System.Drawing.Point(298, 327);
            this.row5_line6.Name = "row5_line6";
            this.row5_line6.Size = new System.Drawing.Size(50, 50);
            this.row5_line6.TabIndex = 35;
            // 
            // row5_line5
            // 
            this.row5_line5.BackColor = System.Drawing.Color.Silver;
            this.row5_line5.Location = new System.Drawing.Point(298, 266);
            this.row5_line5.Name = "row5_line5";
            this.row5_line5.Size = new System.Drawing.Size(50, 50);
            this.row5_line5.TabIndex = 34;
            // 
            // row5_line4
            // 
            this.row5_line4.BackColor = System.Drawing.Color.Silver;
            this.row5_line4.Location = new System.Drawing.Point(298, 203);
            this.row5_line4.Name = "row5_line4";
            this.row5_line4.Size = new System.Drawing.Size(50, 50);
            this.row5_line4.TabIndex = 33;
            // 
            // row5_line3
            // 
            this.row5_line3.BackColor = System.Drawing.Color.Silver;
            this.row5_line3.Location = new System.Drawing.Point(298, 142);
            this.row5_line3.Name = "row5_line3";
            this.row5_line3.Size = new System.Drawing.Size(50, 50);
            this.row5_line3.TabIndex = 32;
            // 
            // row5_line2
            // 
            this.row5_line2.BackColor = System.Drawing.Color.Silver;
            this.row5_line2.Location = new System.Drawing.Point(298, 78);
            this.row5_line2.Name = "row5_line2";
            this.row5_line2.Size = new System.Drawing.Size(50, 50);
            this.row5_line2.TabIndex = 31;
            // 
            // row5_line1
            // 
            this.row5_line1.BackColor = System.Drawing.Color.Silver;
            this.row5_line1.Location = new System.Drawing.Point(298, 15);
            this.row5_line1.Name = "row5_line1";
            this.row5_line1.Size = new System.Drawing.Size(50, 50);
            this.row5_line1.TabIndex = 30;
            // 
            // row4_line6
            // 
            this.row4_line6.BackColor = System.Drawing.Color.Silver;
            this.row4_line6.Location = new System.Drawing.Point(228, 327);
            this.row4_line6.Name = "row4_line6";
            this.row4_line6.Size = new System.Drawing.Size(50, 50);
            this.row4_line6.TabIndex = 29;
            // 
            // row4_line5
            // 
            this.row4_line5.BackColor = System.Drawing.Color.Silver;
            this.row4_line5.Location = new System.Drawing.Point(228, 266);
            this.row4_line5.Name = "row4_line5";
            this.row4_line5.Size = new System.Drawing.Size(50, 50);
            this.row4_line5.TabIndex = 28;
            // 
            // row4_line4
            // 
            this.row4_line4.BackColor = System.Drawing.Color.Silver;
            this.row4_line4.Location = new System.Drawing.Point(228, 203);
            this.row4_line4.Name = "row4_line4";
            this.row4_line4.Size = new System.Drawing.Size(50, 50);
            this.row4_line4.TabIndex = 27;
            // 
            // row4_line3
            // 
            this.row4_line3.BackColor = System.Drawing.Color.Silver;
            this.row4_line3.Location = new System.Drawing.Point(228, 142);
            this.row4_line3.Name = "row4_line3";
            this.row4_line3.Size = new System.Drawing.Size(50, 50);
            this.row4_line3.TabIndex = 26;
            // 
            // row4_line2
            // 
            this.row4_line2.BackColor = System.Drawing.Color.Silver;
            this.row4_line2.Location = new System.Drawing.Point(228, 78);
            this.row4_line2.Name = "row4_line2";
            this.row4_line2.Size = new System.Drawing.Size(50, 50);
            this.row4_line2.TabIndex = 25;
            // 
            // row4_line1
            // 
            this.row4_line1.BackColor = System.Drawing.Color.Silver;
            this.row4_line1.Location = new System.Drawing.Point(228, 15);
            this.row4_line1.Name = "row4_line1";
            this.row4_line1.Size = new System.Drawing.Size(50, 50);
            this.row4_line1.TabIndex = 24;
            // 
            // row3_line6
            // 
            this.row3_line6.BackColor = System.Drawing.Color.Silver;
            this.row3_line6.Location = new System.Drawing.Point(159, 327);
            this.row3_line6.Name = "row3_line6";
            this.row3_line6.Size = new System.Drawing.Size(50, 50);
            this.row3_line6.TabIndex = 23;
            // 
            // row3_line5
            // 
            this.row3_line5.BackColor = System.Drawing.Color.Silver;
            this.row3_line5.Location = new System.Drawing.Point(159, 266);
            this.row3_line5.Name = "row3_line5";
            this.row3_line5.Size = new System.Drawing.Size(50, 50);
            this.row3_line5.TabIndex = 22;
            // 
            // row3_line4
            // 
            this.row3_line4.BackColor = System.Drawing.Color.Silver;
            this.row3_line4.Location = new System.Drawing.Point(159, 203);
            this.row3_line4.Name = "row3_line4";
            this.row3_line4.Size = new System.Drawing.Size(50, 50);
            this.row3_line4.TabIndex = 21;
            // 
            // row3_line3
            // 
            this.row3_line3.BackColor = System.Drawing.Color.Silver;
            this.row3_line3.Location = new System.Drawing.Point(159, 142);
            this.row3_line3.Name = "row3_line3";
            this.row3_line3.Size = new System.Drawing.Size(50, 50);
            this.row3_line3.TabIndex = 20;
            // 
            // row3_line2
            // 
            this.row3_line2.BackColor = System.Drawing.Color.Silver;
            this.row3_line2.Location = new System.Drawing.Point(159, 78);
            this.row3_line2.Name = "row3_line2";
            this.row3_line2.Size = new System.Drawing.Size(50, 50);
            this.row3_line2.TabIndex = 19;
            // 
            // row3_line1
            // 
            this.row3_line1.BackColor = System.Drawing.Color.Silver;
            this.row3_line1.Location = new System.Drawing.Point(159, 15);
            this.row3_line1.Name = "row3_line1";
            this.row3_line1.Size = new System.Drawing.Size(50, 50);
            this.row3_line1.TabIndex = 18;
            // 
            // row2_line6
            // 
            this.row2_line6.BackColor = System.Drawing.Color.Silver;
            this.row2_line6.Location = new System.Drawing.Point(89, 327);
            this.row2_line6.Name = "row2_line6";
            this.row2_line6.Size = new System.Drawing.Size(50, 50);
            this.row2_line6.TabIndex = 17;
            // 
            // row2_line5
            // 
            this.row2_line5.BackColor = System.Drawing.Color.Silver;
            this.row2_line5.Location = new System.Drawing.Point(89, 266);
            this.row2_line5.Name = "row2_line5";
            this.row2_line5.Size = new System.Drawing.Size(50, 50);
            this.row2_line5.TabIndex = 16;
            // 
            // row2_line4
            // 
            this.row2_line4.BackColor = System.Drawing.Color.Silver;
            this.row2_line4.Location = new System.Drawing.Point(89, 203);
            this.row2_line4.Name = "row2_line4";
            this.row2_line4.Size = new System.Drawing.Size(50, 50);
            this.row2_line4.TabIndex = 15;
            // 
            // row2_line3
            // 
            this.row2_line3.BackColor = System.Drawing.Color.Silver;
            this.row2_line3.Location = new System.Drawing.Point(89, 142);
            this.row2_line3.Name = "row2_line3";
            this.row2_line3.Size = new System.Drawing.Size(50, 50);
            this.row2_line3.TabIndex = 14;
            // 
            // row2_line2
            // 
            this.row2_line2.BackColor = System.Drawing.Color.Silver;
            this.row2_line2.Location = new System.Drawing.Point(89, 78);
            this.row2_line2.Name = "row2_line2";
            this.row2_line2.Size = new System.Drawing.Size(50, 50);
            this.row2_line2.TabIndex = 13;
            // 
            // row2_line1
            // 
            this.row2_line1.BackColor = System.Drawing.Color.Silver;
            this.row2_line1.Location = new System.Drawing.Point(89, 15);
            this.row2_line1.Name = "row2_line1";
            this.row2_line1.Size = new System.Drawing.Size(50, 50);
            this.row2_line1.TabIndex = 12;
            // 
            // row1_line6
            // 
            this.row1_line6.BackColor = System.Drawing.Color.Silver;
            this.row1_line6.Location = new System.Drawing.Point(17, 327);
            this.row1_line6.Name = "row1_line6";
            this.row1_line6.Size = new System.Drawing.Size(50, 50);
            this.row1_line6.TabIndex = 11;
            // 
            // row1_line5
            // 
            this.row1_line5.BackColor = System.Drawing.Color.Silver;
            this.row1_line5.Location = new System.Drawing.Point(17, 266);
            this.row1_line5.Name = "row1_line5";
            this.row1_line5.Size = new System.Drawing.Size(50, 50);
            this.row1_line5.TabIndex = 10;
            // 
            // row1_line4
            // 
            this.row1_line4.BackColor = System.Drawing.Color.Silver;
            this.row1_line4.Location = new System.Drawing.Point(17, 203);
            this.row1_line4.Name = "row1_line4";
            this.row1_line4.Size = new System.Drawing.Size(50, 50);
            this.row1_line4.TabIndex = 9;
            // 
            // row1_line3
            // 
            this.row1_line3.BackColor = System.Drawing.Color.Silver;
            this.row1_line3.Location = new System.Drawing.Point(17, 142);
            this.row1_line3.Name = "row1_line3";
            this.row1_line3.Size = new System.Drawing.Size(50, 50);
            this.row1_line3.TabIndex = 8;
            // 
            // row1_line2
            // 
            this.row1_line2.BackColor = System.Drawing.Color.Silver;
            this.row1_line2.Location = new System.Drawing.Point(17, 78);
            this.row1_line2.Name = "row1_line2";
            this.row1_line2.Size = new System.Drawing.Size(50, 50);
            this.row1_line2.TabIndex = 7;
            // 
            // row1_line1
            // 
            this.row1_line1.BackColor = System.Drawing.Color.Silver;
            this.row1_line1.Location = new System.Drawing.Point(17, 15);
            this.row1_line1.Name = "row1_line1";
            this.row1_line1.Size = new System.Drawing.Size(50, 50);
            this.row1_line1.TabIndex = 0;
            // 
            // gB_VierGewinnt
            // 
            this.gB_VierGewinnt.Controls.Add(this.row7);
            this.gB_VierGewinnt.Controls.Add(this.row6);
            this.gB_VierGewinnt.Controls.Add(this.row5);
            this.gB_VierGewinnt.Controls.Add(this.row4);
            this.gB_VierGewinnt.Controls.Add(this.row3);
            this.gB_VierGewinnt.Controls.Add(this.row2);
            this.gB_VierGewinnt.Controls.Add(this.row1);
            this.gB_VierGewinnt.Location = new System.Drawing.Point(39, 26);
            this.gB_VierGewinnt.Name = "gB_VierGewinnt";
            this.gB_VierGewinnt.Size = new System.Drawing.Size(504, 100);
            this.gB_VierGewinnt.TabIndex = 1;
            this.gB_VierGewinnt.TabStop = false;
            this.gB_VierGewinnt.Text = "4-Gewinnt";
            // 
            // row7
            // 
            this.row7.BackColor = System.Drawing.Color.White;
            this.row7.Location = new System.Drawing.Point(438, 42);
            this.row7.Name = "row7";
            this.row7.Size = new System.Drawing.Size(47, 38);
            this.row7.TabIndex = 6;
            this.row7.Text = "Klick";
            this.row7.UseVisualStyleBackColor = false;
            this.row7.Click += new System.EventHandler(this.row7_Click);
            // 
            // row6
            // 
            this.row6.BackColor = System.Drawing.Color.White;
            this.row6.Location = new System.Drawing.Point(370, 42);
            this.row6.Name = "row6";
            this.row6.Size = new System.Drawing.Size(47, 38);
            this.row6.TabIndex = 5;
            this.row6.Text = "Klick";
            this.row6.UseVisualStyleBackColor = false;
            this.row6.Click += new System.EventHandler(this.row6_Click);
            // 
            // row5
            // 
            this.row5.BackColor = System.Drawing.Color.White;
            this.row5.Location = new System.Drawing.Point(301, 42);
            this.row5.Name = "row5";
            this.row5.Size = new System.Drawing.Size(47, 38);
            this.row5.TabIndex = 4;
            this.row5.Text = "Klick";
            this.row5.UseVisualStyleBackColor = false;
            this.row5.Click += new System.EventHandler(this.row5_Click);
            // 
            // row4
            // 
            this.row4.BackColor = System.Drawing.Color.White;
            this.row4.Location = new System.Drawing.Point(231, 42);
            this.row4.Name = "row4";
            this.row4.Size = new System.Drawing.Size(47, 38);
            this.row4.TabIndex = 3;
            this.row4.Text = "Klick";
            this.row4.UseVisualStyleBackColor = false;
            this.row4.Click += new System.EventHandler(this.row4_Click);
            // 
            // row3
            // 
            this.row3.BackColor = System.Drawing.Color.White;
            this.row3.Location = new System.Drawing.Point(162, 42);
            this.row3.Name = "row3";
            this.row3.Size = new System.Drawing.Size(47, 38);
            this.row3.TabIndex = 2;
            this.row3.Text = "Klick";
            this.row3.UseVisualStyleBackColor = false;
            this.row3.Click += new System.EventHandler(this.row3_Click);
            // 
            // row2
            // 
            this.row2.BackColor = System.Drawing.Color.White;
            this.row2.Location = new System.Drawing.Point(92, 42);
            this.row2.Name = "row2";
            this.row2.Size = new System.Drawing.Size(47, 38);
            this.row2.TabIndex = 1;
            this.row2.Text = "Klick";
            this.row2.UseVisualStyleBackColor = false;
            this.row2.Click += new System.EventHandler(this.row2_Click);
            // 
            // row1
            // 
            this.row1.BackColor = System.Drawing.Color.White;
            this.row1.Location = new System.Drawing.Point(20, 42);
            this.row1.Name = "row1";
            this.row1.Size = new System.Drawing.Size(47, 38);
            this.row1.TabIndex = 0;
            this.row1.Text = "Klick";
            this.row1.UseVisualStyleBackColor = false;
            this.row1.Click += new System.EventHandler(this.row1_Click);
            // 
            // txt_info
            // 
            this.txt_info.Location = new System.Drawing.Point(39, 552);
            this.txt_info.Margin = new System.Windows.Forms.Padding(0);
            this.txt_info.Name = "txt_info";
            this.txt_info.ReadOnly = true;
            this.txt_info.Size = new System.Drawing.Size(504, 20);
            this.txt_info.TabIndex = 2;
            // 
            // VierGewinnt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.txt_info);
            this.Controls.Add(this.gB_VierGewinnt);
            this.Controls.Add(this.p_VierGewinnt);
            this.Name = "VierGewinnt";
            this.Size = new System.Drawing.Size(586, 595);
            this.p_VierGewinnt.ResumeLayout(false);
            this.gB_VierGewinnt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel p_VierGewinnt;
        private System.Windows.Forms.GroupBox gB_VierGewinnt;
        private System.Windows.Forms.Button row1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label row1_line1;
        private System.Windows.Forms.Label row7_line6;
        private System.Windows.Forms.Label row7_line5;
        private System.Windows.Forms.Label row7_line4;
        private System.Windows.Forms.Label row7_line3;
        private System.Windows.Forms.Label row7_line2;
        private System.Windows.Forms.Label row7_line1;
        private System.Windows.Forms.Label row6_line6;
        private System.Windows.Forms.Label row6_line5;
        private System.Windows.Forms.Label row6_line4;
        private System.Windows.Forms.Label row6_line3;
        private System.Windows.Forms.Label row6_line2;
        private System.Windows.Forms.Label row6_line1;
        private System.Windows.Forms.Label row5_line6;
        private System.Windows.Forms.Label row5_line5;
        private System.Windows.Forms.Label row5_line4;
        private System.Windows.Forms.Label row5_line3;
        private System.Windows.Forms.Label row5_line2;
        private System.Windows.Forms.Label row5_line1;
        private System.Windows.Forms.Label row4_line6;
        private System.Windows.Forms.Label row4_line5;
        private System.Windows.Forms.Label row4_line4;
        private System.Windows.Forms.Label row4_line3;
        private System.Windows.Forms.Label row4_line2;
        private System.Windows.Forms.Label row4_line1;
        private System.Windows.Forms.Label row3_line6;
        private System.Windows.Forms.Label row3_line5;
        private System.Windows.Forms.Label row3_line4;
        private System.Windows.Forms.Label row3_line3;
        private System.Windows.Forms.Label row3_line2;
        private System.Windows.Forms.Label row3_line1;
        private System.Windows.Forms.Label row2_line6;
        private System.Windows.Forms.Label row2_line5;
        private System.Windows.Forms.Label row2_line4;
        private System.Windows.Forms.Label row2_line3;
        private System.Windows.Forms.Label row2_line2;
        private System.Windows.Forms.Label row2_line1;
        private System.Windows.Forms.Label row1_line6;
        private System.Windows.Forms.Label row1_line5;
        private System.Windows.Forms.Label row1_line4;
        private System.Windows.Forms.Label row1_line3;
        private System.Windows.Forms.Label row1_line2;
        private System.Windows.Forms.Button row7;
        private System.Windows.Forms.Button row6;
        private System.Windows.Forms.Button row5;
        private System.Windows.Forms.Button row4;
        private System.Windows.Forms.Button row3;
        private System.Windows.Forms.Button row2;
        private System.Windows.Forms.TextBox txt_info;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}
